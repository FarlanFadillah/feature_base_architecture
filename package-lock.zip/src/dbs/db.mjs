import knex from "knex";
import process from "process";
import "../../env.mjs";
const db = knex({
    client: process.env.DB_CLIENT,
    connection: {
        host: process.env.DB_HOST,
        port: process.env.DB_PORT,
        user: process.env.DB_USER,
        password: process.env.DB_PASS,
        database: process.env.DB_NAME,
        timezone: "Z",
    },
    useNullAsDefault: true,
});

// FOR SQLITE3
// db.raw("PRAGMA foreign_key= ON").then(() => {
//     console.log("SQLite foreign key enabled");
// });

export { db as default };
